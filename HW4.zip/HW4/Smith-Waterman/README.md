## Authors
The code is originally from the CPU-version of the following project:
"Protein alignment algorithms with an efficient backtracking routine on multiple GPUs"
Jacek Blazewicz, Wojciech Frohmberg, Michal Kierzynka, Erwin Pesch and Pawel Wojciechowski
BMC Bioinformatics 2011, 12:181
http://gpualign.cs.put.poznan.pl/project-gpu-pairAlign.html

## License
GNU GPLv3
