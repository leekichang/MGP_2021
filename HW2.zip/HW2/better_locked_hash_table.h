#ifndef _BETTER_LOCKED_HASH_TABLE_H_
#define _BETTER_LOCKED_HASH_TABLE_H_

#define TABLE_SIZE 1000

#include <iostream>
#include <mutex>
#include <thread>
#include "hash_table.h"
#include "linked_list.h"

class better_locked_hash_table : public hash_table {

    // TODO
    

    // TODO 

    public:
        better_locked_hash_table(){
            // TODO
            

            // TODO
        }

        bool contains(int key){
            // TODO


            // TODO
        }

        
        bool insert(int key) {
            // TODO


            // TODO
        }

        bool remove(int key) {
            // TODO


            // TODO
        }
};

#endif